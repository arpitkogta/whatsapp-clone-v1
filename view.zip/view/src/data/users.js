var users = [
    {
        name: 'Priyansh Jain',
        contact: '9038706861'
    },
    {
        name: 'Abhishek Goyal',
        contact: '9038706862'
    },
    {
        name: 'Snehil Jain',
        contact: '9038706863'
    },
    {
        name: 'Ananya Bhatnagar',
        contact: '9038706864'
    },
    {
        name: 'Kundhavai Maam',
        contact: '9038706865'
    },
    {
        name: 'Abhigyan Manasvi',
        contact: '9038706865'
    },
    {
        name: 'Samriddhi Vishwakarma',
        contact: '9038706867'
    },
    {
        name: 'Anwesh Bhagat',
        contact: '9038706868'
    },
    {
        name: 'Mom',
        contact: '9038706869'
    },
    {
        name: 'Dad',
        contact: '9038706870'
    }
]

export default users;